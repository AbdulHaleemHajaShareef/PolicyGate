function escapeRegExp(input) {
  return input.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function wildcardToRegExp(pattern) {
  const escaped = escapeRegExp(pattern).replace(/\\\*/g, '.*');
  return new RegExp(`^${escaped}$`);
}

function matchesPattern(pattern, value) {
  if (pattern === '*') {
    return true;
  }

  if (typeof pattern !== 'string' || typeof value !== 'string') {
    return false;
  }

  return wildcardToRegExp(pattern).test(value);
}

module.exports = {
  matchesPattern,
  wildcardToRegExp,
};
